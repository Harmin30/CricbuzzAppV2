﻿//using CricbuzzAppV2.Models;
//using Microsoft.AspNetCore.Mvc.Rendering;

//namespace CricbuzzAppV2.ViewModels
//{
//    public class PlayerCreateViewModel
//    {
//        public Player Player { get; set; }
//        public SelectList Teams { get; set; }
//    }
//}
